﻿namespace DP_Opdracht2_Pull
{
    public interface iPullObserver
    {
        void UpdateData();
    }
}
