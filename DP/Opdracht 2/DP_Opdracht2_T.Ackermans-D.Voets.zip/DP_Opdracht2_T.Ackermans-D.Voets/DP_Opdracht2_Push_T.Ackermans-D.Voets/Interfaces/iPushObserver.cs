﻿namespace DP_Opdracht2_Push
{
    public interface iPushObserver
    {
        void UpdateData(int data);
    }
}
