﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class SuperMegaDeathCar : iVehicle
    {
        public string drive()
        {
            return "VRoooMmMmM!";
        }

        public string honk()
        {
            return "!HoNk hOnK!";
        }
    }
}
