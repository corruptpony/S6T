﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class Banana : iFood
    {
        public string eat()
        {
            return "BANANANANANANANANANANANA";
        }
    }
}
