﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class Minioness : iFemaleFigure
    {
        public string cook()
        {
            return "Preparing delicious meal";
        }

        public string sing()
        {
            return "BEEDOOBEEDOOBEEEDOO";
        }
    }
}
