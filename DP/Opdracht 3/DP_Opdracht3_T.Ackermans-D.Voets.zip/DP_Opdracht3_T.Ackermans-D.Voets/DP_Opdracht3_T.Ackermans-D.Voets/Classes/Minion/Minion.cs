﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class Minion : iMaleFigure
    {
        public string fight()
        {
            return "POW";
        }

        public string work()
        {
            return "Making super mega death rocket";
        }
    }
}
