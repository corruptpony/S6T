﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class GruHouse : iHouse
    {
        public string collapse()
        {
            return "BOOM bang krak shake!";
        }

        public string squeak()
        {
            return "IIIEEEEEEEHH";
        }
    }
}
