﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class Smurfin : iFemaleFigure
    {
        public string cook()
        {
           return "Smurfing food";
        }

        public string sing()
        {
            return "smurf ^ smurf V smurf";
        }
    }
}
