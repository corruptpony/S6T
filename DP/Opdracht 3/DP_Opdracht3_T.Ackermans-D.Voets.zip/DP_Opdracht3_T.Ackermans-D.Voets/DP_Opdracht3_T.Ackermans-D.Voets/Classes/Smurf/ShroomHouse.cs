﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class ShroomHouse : iHouse
    {
        public string collapse()
        {
            return "Knak";
        }

        public string squeak()
        {
           return "RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR";
        }
    }
}
