﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class Mushroom : iFood
    {
        public string eat()
        {
            return "Smurfing nomnomnom";
        }
    }
}
