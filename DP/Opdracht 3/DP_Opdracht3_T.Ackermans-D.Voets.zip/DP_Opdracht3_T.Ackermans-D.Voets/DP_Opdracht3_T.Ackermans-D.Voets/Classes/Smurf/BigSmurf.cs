﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class BigSmurf : iMaleFigure
    {
        public string fight()
        {
            return "SmurfPunch";
        }

        public string work()
        {
            return "Smurfing";
        }
    }
}
