﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    class ShanksPony : iVehicle
    {
        public string drive()
        {
            return "TipTapTipTap Smurfing";
        }

        public string honk()
        {
            return "SmurF SmurF";
        }
    }
}
