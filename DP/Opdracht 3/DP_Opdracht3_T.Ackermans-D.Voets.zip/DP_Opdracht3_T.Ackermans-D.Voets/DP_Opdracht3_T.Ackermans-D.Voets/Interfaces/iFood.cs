﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    interface iFood
    {
        string eat();
    }
}
