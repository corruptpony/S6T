﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    interface iHouse
    {
        string squeak();
        string collapse();
    }
}
