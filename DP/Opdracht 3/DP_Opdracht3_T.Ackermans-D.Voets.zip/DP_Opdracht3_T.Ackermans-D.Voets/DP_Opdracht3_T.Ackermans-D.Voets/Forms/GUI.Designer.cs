﻿namespace DP_Opdracht3_T.Ackermans_D.Voets
{
    partial class GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbFactorySelector = new System.Windows.Forms.ComboBox();
            this.gbFemaleFigure = new System.Windows.Forms.GroupBox();
            this.lblFemaleProp2 = new System.Windows.Forms.Label();
            this.lblFemaleProp1 = new System.Windows.Forms.Label();
            this.gbMaleFigure = new System.Windows.Forms.GroupBox();
            this.lblMaleProp2 = new System.Windows.Forms.Label();
            this.lblMaleProp1 = new System.Windows.Forms.Label();
            this.gbFood = new System.Windows.Forms.GroupBox();
            this.lblFoodProp1 = new System.Windows.Forms.Label();
            this.gbVehicle = new System.Windows.Forms.GroupBox();
            this.lblVehicleProp2 = new System.Windows.Forms.Label();
            this.lblVehicleProp1 = new System.Windows.Forms.Label();
            this.gbHouse = new System.Windows.Forms.GroupBox();
            this.lblHouseProp2 = new System.Windows.Forms.Label();
            this.lblHouseProp1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.gbFemaleFigure.SuspendLayout();
            this.gbMaleFigure.SuspendLayout();
            this.gbFood.SuspendLayout();
            this.gbVehicle.SuspendLayout();
            this.gbHouse.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbFactorySelector
            // 
            this.cbFactorySelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFactorySelector.FormattingEnabled = true;
            this.cbFactorySelector.Location = new System.Drawing.Point(13, 13);
            this.cbFactorySelector.Name = "cbFactorySelector";
            this.cbFactorySelector.Size = new System.Drawing.Size(121, 21);
            this.cbFactorySelector.TabIndex = 1;
            this.cbFactorySelector.SelectedValueChanged += new System.EventHandler(this.cbFactorySelector_SelectedValueChanged);
            // 
            // gbFemaleFigure
            // 
            this.gbFemaleFigure.Controls.Add(this.lblFemaleProp2);
            this.gbFemaleFigure.Controls.Add(this.lblFemaleProp1);
            this.gbFemaleFigure.Location = new System.Drawing.Point(196, 13);
            this.gbFemaleFigure.Name = "gbFemaleFigure";
            this.gbFemaleFigure.Size = new System.Drawing.Size(325, 54);
            this.gbFemaleFigure.TabIndex = 2;
            this.gbFemaleFigure.TabStop = false;
            this.gbFemaleFigure.Text = "Female Figure";
            // 
            // lblFemaleProp2
            // 
            this.lblFemaleProp2.AutoSize = true;
            this.lblFemaleProp2.Location = new System.Drawing.Point(7, 33);
            this.lblFemaleProp2.Name = "lblFemaleProp2";
            this.lblFemaleProp2.Size = new System.Drawing.Size(35, 13);
            this.lblFemaleProp2.TabIndex = 1;
            this.lblFemaleProp2.Text = "label2";
            // 
            // lblFemaleProp1
            // 
            this.lblFemaleProp1.AutoSize = true;
            this.lblFemaleProp1.Location = new System.Drawing.Point(7, 20);
            this.lblFemaleProp1.Name = "lblFemaleProp1";
            this.lblFemaleProp1.Size = new System.Drawing.Size(35, 13);
            this.lblFemaleProp1.TabIndex = 0;
            this.lblFemaleProp1.Text = "label1";
            // 
            // gbMaleFigure
            // 
            this.gbMaleFigure.Controls.Add(this.lblMaleProp2);
            this.gbMaleFigure.Controls.Add(this.lblMaleProp1);
            this.gbMaleFigure.Location = new System.Drawing.Point(196, 73);
            this.gbMaleFigure.Name = "gbMaleFigure";
            this.gbMaleFigure.Size = new System.Drawing.Size(325, 56);
            this.gbMaleFigure.TabIndex = 3;
            this.gbMaleFigure.TabStop = false;
            this.gbMaleFigure.Text = "Male Figure";
            // 
            // lblMaleProp2
            // 
            this.lblMaleProp2.AutoSize = true;
            this.lblMaleProp2.Location = new System.Drawing.Point(7, 33);
            this.lblMaleProp2.Name = "lblMaleProp2";
            this.lblMaleProp2.Size = new System.Drawing.Size(35, 13);
            this.lblMaleProp2.TabIndex = 1;
            this.lblMaleProp2.Text = "label3";
            // 
            // lblMaleProp1
            // 
            this.lblMaleProp1.AutoSize = true;
            this.lblMaleProp1.Location = new System.Drawing.Point(7, 20);
            this.lblMaleProp1.Name = "lblMaleProp1";
            this.lblMaleProp1.Size = new System.Drawing.Size(35, 13);
            this.lblMaleProp1.TabIndex = 0;
            this.lblMaleProp1.Text = "label4";
            // 
            // gbFood
            // 
            this.gbFood.Controls.Add(this.lblFoodProp1);
            this.gbFood.Location = new System.Drawing.Point(196, 135);
            this.gbFood.Name = "gbFood";
            this.gbFood.Size = new System.Drawing.Size(325, 56);
            this.gbFood.TabIndex = 4;
            this.gbFood.TabStop = false;
            this.gbFood.Text = "Food";
            // 
            // lblFoodProp1
            // 
            this.lblFoodProp1.AutoSize = true;
            this.lblFoodProp1.Location = new System.Drawing.Point(7, 20);
            this.lblFoodProp1.Name = "lblFoodProp1";
            this.lblFoodProp1.Size = new System.Drawing.Size(35, 13);
            this.lblFoodProp1.TabIndex = 0;
            this.lblFoodProp1.Text = "label6";
            // 
            // gbVehicle
            // 
            this.gbVehicle.Controls.Add(this.lblVehicleProp2);
            this.gbVehicle.Controls.Add(this.lblVehicleProp1);
            this.gbVehicle.Location = new System.Drawing.Point(196, 197);
            this.gbVehicle.Name = "gbVehicle";
            this.gbVehicle.Size = new System.Drawing.Size(325, 56);
            this.gbVehicle.TabIndex = 5;
            this.gbVehicle.TabStop = false;
            this.gbVehicle.Text = "Vehicle";
            // 
            // lblVehicleProp2
            // 
            this.lblVehicleProp2.AutoSize = true;
            this.lblVehicleProp2.Location = new System.Drawing.Point(7, 33);
            this.lblVehicleProp2.Name = "lblVehicleProp2";
            this.lblVehicleProp2.Size = new System.Drawing.Size(35, 13);
            this.lblVehicleProp2.TabIndex = 1;
            this.lblVehicleProp2.Text = "label7";
            // 
            // lblVehicleProp1
            // 
            this.lblVehicleProp1.AutoSize = true;
            this.lblVehicleProp1.Location = new System.Drawing.Point(7, 20);
            this.lblVehicleProp1.Name = "lblVehicleProp1";
            this.lblVehicleProp1.Size = new System.Drawing.Size(35, 13);
            this.lblVehicleProp1.TabIndex = 0;
            this.lblVehicleProp1.Text = "label8";
            // 
            // gbHouse
            // 
            this.gbHouse.Controls.Add(this.lblHouseProp2);
            this.gbHouse.Controls.Add(this.lblHouseProp1);
            this.gbHouse.Location = new System.Drawing.Point(196, 259);
            this.gbHouse.Name = "gbHouse";
            this.gbHouse.Size = new System.Drawing.Size(325, 56);
            this.gbHouse.TabIndex = 6;
            this.gbHouse.TabStop = false;
            this.gbHouse.Text = "House";
            // 
            // lblHouseProp2
            // 
            this.lblHouseProp2.AutoSize = true;
            this.lblHouseProp2.Location = new System.Drawing.Point(7, 33);
            this.lblHouseProp2.Name = "lblHouseProp2";
            this.lblHouseProp2.Size = new System.Drawing.Size(35, 13);
            this.lblHouseProp2.TabIndex = 1;
            this.lblHouseProp2.Text = "label5";
            // 
            // lblHouseProp1
            // 
            this.lblHouseProp1.AutoSize = true;
            this.lblHouseProp1.Location = new System.Drawing.Point(7, 20);
            this.lblHouseProp1.Name = "lblHouseProp1";
            this.lblHouseProp1.Size = new System.Drawing.Size(35, 13);
            this.lblHouseProp1.TabIndex = 0;
            this.lblHouseProp1.Text = "label9";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Singing";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Cooking";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(144, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Working";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(144, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Fighting";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(144, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Eating";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(144, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Driving";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(144, 230);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Honking";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(144, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Squeaking";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(144, 292);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Collapsing";
            // 
            // GUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 334);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbHouse);
            this.Controls.Add(this.gbVehicle);
            this.Controls.Add(this.gbFood);
            this.Controls.Add(this.gbMaleFigure);
            this.Controls.Add(this.gbFemaleFigure);
            this.Controls.Add(this.cbFactorySelector);
            this.Name = "GUI";
            this.Text = "GUI";
            this.gbFemaleFigure.ResumeLayout(false);
            this.gbFemaleFigure.PerformLayout();
            this.gbMaleFigure.ResumeLayout(false);
            this.gbMaleFigure.PerformLayout();
            this.gbFood.ResumeLayout(false);
            this.gbFood.PerformLayout();
            this.gbVehicle.ResumeLayout(false);
            this.gbVehicle.PerformLayout();
            this.gbHouse.ResumeLayout(false);
            this.gbHouse.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbFactorySelector;
        private System.Windows.Forms.GroupBox gbFemaleFigure;
        private System.Windows.Forms.Label lblFemaleProp2;
        private System.Windows.Forms.Label lblFemaleProp1;
        private System.Windows.Forms.GroupBox gbMaleFigure;
        private System.Windows.Forms.Label lblMaleProp2;
        private System.Windows.Forms.Label lblMaleProp1;
        private System.Windows.Forms.GroupBox gbFood;
        private System.Windows.Forms.Label lblFoodProp1;
        private System.Windows.Forms.GroupBox gbVehicle;
        private System.Windows.Forms.Label lblVehicleProp2;
        private System.Windows.Forms.Label lblVehicleProp1;
        private System.Windows.Forms.GroupBox gbHouse;
        private System.Windows.Forms.Label lblHouseProp2;
        private System.Windows.Forms.Label lblHouseProp1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

