﻿namespace Opdracht4_Decorator_TAckermans_DVoets
{
    interface iBeverage
    {
        double cost();
    }
}
