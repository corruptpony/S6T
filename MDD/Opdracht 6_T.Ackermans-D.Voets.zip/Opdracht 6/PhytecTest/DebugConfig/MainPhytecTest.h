/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: DebugConfig
	Model Element	: DebugConfig
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/DebugConfig/MainPhytecTest.h
*********************************************************************/

#ifndef MainPhytecTest_H
#define MainPhytecTest_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include "DebugDefs.h"
#endif
/*********************************************************************
	File Path	: PhytecTest/DebugConfig/MainPhytecTest.h
*********************************************************************/
