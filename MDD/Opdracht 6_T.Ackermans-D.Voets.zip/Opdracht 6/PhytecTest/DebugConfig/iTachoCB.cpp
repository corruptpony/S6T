/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: DebugConfig
	Model Element	: iTachoCB
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/DebugConfig/iTachoCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iTachoCB.h"
//## package DesignTacho

//## class iTachoCB

using namespace std;

iTachoCB::iTachoCB() {
}

iTachoCB::~iTachoCB() {
}

/*********************************************************************
	File Path	: PhytecTest/DebugConfig/iTachoCB.cpp
*********************************************************************/
