/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: DebugConfig
	Model Element	: iMotor
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/DebugConfig/iMotor.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iMotor.h"
//## package DesignMotor

//## class iMotor

using namespace std;

iMotor::iMotor() {
}

iMotor::~iMotor() {
}

/*********************************************************************
	File Path	: PhytecTest/DebugConfig/iMotor.cpp
*********************************************************************/
