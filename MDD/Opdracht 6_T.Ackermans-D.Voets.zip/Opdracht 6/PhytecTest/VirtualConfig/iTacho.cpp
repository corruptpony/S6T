/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iTacho
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/VirtualConfig/iTacho.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iTacho.h"
//## auto_generated
#include "fstream"
//## package DesignTacho

//## class iTacho

using namespace std;

iTacho::iTacho() {
}

iTacho::~iTacho() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iTacho.cpp
*********************************************************************/
