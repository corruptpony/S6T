/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: Application
//!	Generated Date	: Tue, 14, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/Application.cpp
*********************************************************************/

//## auto_generated
#include "Application.h"
//## package Analyse

//## class Application

using namespace std;

Application::Application() {
}

Application::~Application() {
}

/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/Application.cpp
*********************************************************************/
