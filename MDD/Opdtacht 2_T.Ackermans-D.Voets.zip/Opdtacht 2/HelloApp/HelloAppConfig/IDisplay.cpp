/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: IDisplay
//!	Generated Date	: Mon, 20, Mar 2017  
	File Path	: HelloApp/HelloAppConfig/IDisplay.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "IDisplay.h"
//## package Design

//## class IDisplay

using namespace std;

IDisplay::IDisplay() {
}

IDisplay::~IDisplay() {
}

/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/IDisplay.cpp
*********************************************************************/
