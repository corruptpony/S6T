/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: Application
//!	Generated Date	: Tue, 14, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/Application.h
*********************************************************************/

#ifndef Application_H
#define Application_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include <string>
//## auto_generated
#include <iostream>
//## auto_generated
#include <fstream>
//## auto_generated
#include <vector>
//## package Analyse

//## class Application
class Application {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    Application();
    
    //## auto_generated
    ~Application();
};

#endif
/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/Application.h
*********************************************************************/
