/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HexapodModel 
	Configuration 	: DebugConfig
	Model Element	: ILegCB
//!	Generated Date	: Fri, 21, Apr 2017  
	File Path	: HexapodModel/DebugConfig/ILegCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "ILegCB.h"
//## package Design

//## class ILegCB

using namespace std;

ILegCB::ILegCB() {
}

ILegCB::~ILegCB() {
}

/*********************************************************************
	File Path	: HexapodModel/DebugConfig/ILegCB.cpp
*********************************************************************/
