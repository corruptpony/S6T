/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HexapodModel 
	Configuration 	: DebugConfig
	Model Element	: Test
//!	Generated Date	: Fri, 21, Apr 2017  
	File Path	: HexapodModel/DebugConfig/Test.h
*********************************************************************/

#ifndef Test_H
#define Test_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include <aom/aom.h>
//## auto_generated
class HexapodFirmware;

//## package Test



#endif
/*********************************************************************
	File Path	: HexapodModel/DebugConfig/Test.h
*********************************************************************/
