/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HexapodModel 
	Configuration 	: DebugConfig
	Model Element	: DebugConfig
//!	Generated Date	: Fri, 21, Apr 2017  
	File Path	: HexapodModel/DebugConfig/MainHexapodModel.h
*********************************************************************/

#ifndef MainHexapodModel_H
#define MainHexapodModel_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
#endif
/*********************************************************************
	File Path	: HexapodModel/DebugConfig/MainHexapodModel.h
*********************************************************************/
