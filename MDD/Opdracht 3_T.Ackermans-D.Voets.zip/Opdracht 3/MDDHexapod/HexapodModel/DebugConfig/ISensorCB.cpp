/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HexapodModel 
	Configuration 	: DebugConfig
	Model Element	: ISensorCB
//!	Generated Date	: Fri, 21, Apr 2017  
	File Path	: HexapodModel/DebugConfig/ISensorCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "ISensorCB.h"
//## package Design

//## class ISensorCB

using namespace std;

ISensorCB::ISensorCB() {
}

ISensorCB::~ISensorCB() {
}

/*********************************************************************
	File Path	: HexapodModel/DebugConfig/ISensorCB.cpp
*********************************************************************/
