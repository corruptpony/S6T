/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HexapodModel 
	Configuration 	: DebugConfig
	Model Element	: ILeg
//!	Generated Date	: Fri, 21, Apr 2017  
	File Path	: HexapodModel/DebugConfig/ILeg.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "ILeg.h"
//## package Design

//## class ILeg

using namespace std;

ILeg::ILeg() {
}

ILeg::~ILeg() {
}

/*********************************************************************
	File Path	: HexapodModel/DebugConfig/ILeg.cpp
*********************************************************************/
