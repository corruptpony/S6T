/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: HelloAppConfig
//!	Generated Date	: Mon, 20, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/MainHelloApp.h
*********************************************************************/

#ifndef MainHelloApp_H
#define MainHelloApp_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
class HelloApp {
    ////    Constructors and destructors    ////
    
public :

    HelloApp();
};

#endif
/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/MainHelloApp.h
*********************************************************************/
