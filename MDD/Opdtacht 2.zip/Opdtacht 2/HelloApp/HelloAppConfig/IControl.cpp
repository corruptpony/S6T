/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: IControl
//!	Generated Date	: Tue, 14, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/IControl.cpp
*********************************************************************/

//## auto_generated
#include "IControl.h"
//## package Design

//## class IControl

using namespace std;

IControl::IControl() {
}

IControl::~IControl() {
}

/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/IControl.cpp
*********************************************************************/
