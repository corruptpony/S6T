/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: IDisplay
//!	Generated Date	: Tue, 14, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/IDisplay.cpp
*********************************************************************/

//## auto_generated
#include "IDisplay.h"
//## package Design

//## class IDisplay

using namespace std;

IDisplay::IDisplay() {
}

IDisplay::~IDisplay() {
}

/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/IDisplay.cpp
*********************************************************************/
