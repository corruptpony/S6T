/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: HelloApp 
	Configuration 	: HelloAppConfig
	Model Element	: IControl
//!	Generated Date	: Tue, 14, Feb 2017  
	File Path	: HelloApp/HelloAppConfig/IControl.h
*********************************************************************/

#ifndef IControl_H
#define IControl_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include <string>
//## auto_generated
#include <iostream>
//## auto_generated
#include <fstream>
//## auto_generated
#include <vector>
//## package Design

//## class IControl
class IControl {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    IControl();
    
    //## auto_generated
    virtual ~IControl();
};

#endif
/*********************************************************************
	File Path	: HelloApp/HelloAppConfig/IControl.h
*********************************************************************/
