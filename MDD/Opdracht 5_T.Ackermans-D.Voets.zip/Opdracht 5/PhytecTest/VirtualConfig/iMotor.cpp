/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iMotor
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/VirtualConfig/iMotor.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iMotor.h"
//## auto_generated
#include "fstream"
//## package DesignMotor

//## class iMotor

using namespace std;

iMotor::iMotor() {
}

iMotor::~iMotor() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iMotor.cpp
*********************************************************************/
