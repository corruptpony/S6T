/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: DebugConfig
	Model Element	: iKeyCB
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/DebugConfig/iKeyCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iKeyCB.h"
//## package Design

//## class iKeyCB

using namespace std;

iKeyCB::iKeyCB() {
}

iKeyCB::~iKeyCB() {
}

/*********************************************************************
	File Path	: PhytecTest/DebugConfig/iKeyCB.cpp
*********************************************************************/
