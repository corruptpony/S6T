/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: PhytecConfig
	Model Element	: iTacho
//!	Generated Date	: Mon, 15, May 2017  
	File Path	: PhytecTest/PhytecConfig/iTacho.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iTacho.h"
//## package DesignTacho

//## class iTacho

using namespace std;

iTacho::iTacho() {
}

iTacho::~iTacho() {
}

/*********************************************************************
	File Path	: PhytecTest/PhytecConfig/iTacho.cpp
*********************************************************************/
