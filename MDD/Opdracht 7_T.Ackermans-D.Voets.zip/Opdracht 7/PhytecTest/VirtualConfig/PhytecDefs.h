/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: PhytecDefs
//!	Generated Date	: Fri, 2, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/PhytecDefs.h
*********************************************************************/

#ifndef PhytecDefs_H
#define PhytecDefs_H

#define SYS "/sys"
#include "CommonDefs.h"


#endif
/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/PhytecDefs.h
*********************************************************************/
