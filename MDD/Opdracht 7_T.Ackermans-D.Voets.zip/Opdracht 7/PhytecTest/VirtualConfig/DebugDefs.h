/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: DebugDefs
//!	Generated Date	: Fri, 2, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/DebugDefs.h
*********************************************************************/

#ifndef DebugDefs_H
#define DebugDefs_H

#define SYS "c:/sys"
#include "CommonDefs.h"



#endif
/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/DebugDefs.h
*********************************************************************/
