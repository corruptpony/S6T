/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iLed
//!	Generated Date	: Mon, 12, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/iLed.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iLed.h"
//## package Design

//## class iLed

using namespace std;

iLed::iLed() {
}

iLed::~iLed() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iLed.cpp
*********************************************************************/
