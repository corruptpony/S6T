/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: Test
//!	Generated Date	: Mon, 12, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/Test.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "Test.h"
//## auto_generated
#include "PhytecTestSystem.h"
//## package Test


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* aomsAttributes);

IMPLEMENT_META_PACKAGE(Test, Test)

static void serializeGlobalVars(AOMSAttributes* aomsAttributes) {
}
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/Test.cpp
*********************************************************************/
