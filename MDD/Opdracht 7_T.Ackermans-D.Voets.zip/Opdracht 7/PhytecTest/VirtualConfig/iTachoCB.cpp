/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iTachoCB
//!	Generated Date	: Mon, 12, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/iTachoCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iTachoCB.h"
//## package DesignTacho

//## class iTachoCB

using namespace std;

iTachoCB::iTachoCB() {
}

iTachoCB::~iTachoCB() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iTachoCB.cpp
*********************************************************************/
