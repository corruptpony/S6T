/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iKeyCB
//!	Generated Date	: Mon, 12, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/iKeyCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iKeyCB.h"
//## package DesignKey

//## class iKeyCB

using namespace std;

iKeyCB::iKeyCB() {
}

iKeyCB::~iKeyCB() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iKeyCB.cpp
*********************************************************************/
