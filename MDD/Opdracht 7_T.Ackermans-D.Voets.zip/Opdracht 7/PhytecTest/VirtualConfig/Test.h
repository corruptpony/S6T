/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: Test
//!	Generated Date	: Mon, 12, Jun 2017  
	File Path	: PhytecTest/VirtualConfig/Test.h
*********************************************************************/

#ifndef Test_H
#define Test_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include <aom/aom.h>
//## auto_generated
#include "VirtualDefs.h"
//## auto_generated
class PhytecTestSystem;

//## package Test



#endif
/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/Test.h
*********************************************************************/
