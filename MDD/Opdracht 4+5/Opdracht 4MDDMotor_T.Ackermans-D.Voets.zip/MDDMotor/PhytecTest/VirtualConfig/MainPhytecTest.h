/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: VirtualConfig
//!	Generated Date	: Mon, 8, May 2017  
	File Path	: PhytecTest/VirtualConfig/MainPhytecTest.h
*********************************************************************/

#ifndef MainPhytecTest_H
#define MainPhytecTest_H

//## auto_generated
#include <oxf/oxf.h>
//## auto_generated
#include <../Profiles/SysML/SIDefinitions.h>
//## auto_generated
#include "VirtualDefs.h"
#endif
/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/MainPhytecTest.h
*********************************************************************/
