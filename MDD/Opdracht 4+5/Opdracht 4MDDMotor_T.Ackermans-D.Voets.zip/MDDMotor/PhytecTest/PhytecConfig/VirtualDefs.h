/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: PhytecConfig
	Model Element	: VirtualDefs
//!	Generated Date	: Mon, 8, May 2017  
	File Path	: PhytecTest/PhytecConfig/VirtualDefs.h
*********************************************************************/

#ifndef VirtualDefs_H
#define VirtualDefs_H

#define SYS "s:"
#include "CommonDefs.h"


#endif
/*********************************************************************
	File Path	: PhytecTest/PhytecConfig/VirtualDefs.h
*********************************************************************/
