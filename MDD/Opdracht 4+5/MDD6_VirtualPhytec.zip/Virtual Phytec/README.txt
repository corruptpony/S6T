Virtual Phytec
==============
This software simulates the Phytec target hardware on PC/Windows.

Installation
------------
Double-click "DokanInstall_0.6.0.exe" to install Dokan driver.

Usage
-----
Double-click "VirtualPhytec.exe" to start Virtual Phytec. Its GUI will show up on the screen.

When you stop the GUI the Virtual Phytec program keeps running in the taskbar. It is visible as a green round (10)-icon in the lower-right angle of your screen.
By clicking on this icon you can make thye GUI appear again.
Always have only 1 Virtual Phytec running, i.e. there should only be 1 green round (10)-icon. 
