/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: PhytecDefs
//!	Generated Date	: Mon, 8, May 2017  
	File Path	: PhytecTest/VirtualConfig/PhytecDefs.h
*********************************************************************/

#ifndef PhytecDefs_H
#define PhytecDefs_H

#define SYS "/sys"
#include "CommonDefs.h"


#endif
/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/PhytecDefs.h
*********************************************************************/
