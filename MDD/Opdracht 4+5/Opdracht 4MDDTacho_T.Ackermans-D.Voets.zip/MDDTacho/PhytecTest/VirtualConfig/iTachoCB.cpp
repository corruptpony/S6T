/********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: VirtualConfig
	Model Element	: iTachoCB
//!	Generated Date	: Mon, 8, May 2017  
	File Path	: PhytecTest/VirtualConfig/iTachoCB.cpp
*********************************************************************/

//## auto_generated
#include <oxf/omthread.h>
//## auto_generated
#include "iTachoCB.h"
//## auto_generated
#include <fstream>
//## package Design

//## class iTachoCB

using namespace std;

iTachoCB::iTachoCB() {
}

iTachoCB::~iTachoCB() {
}

/*********************************************************************
	File Path	: PhytecTest/VirtualConfig/iTachoCB.cpp
*********************************************************************/
