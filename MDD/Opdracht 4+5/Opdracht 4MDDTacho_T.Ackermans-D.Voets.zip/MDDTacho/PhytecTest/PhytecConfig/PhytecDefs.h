/*********************************************************************
	Rhapsody	: 7.4 
	Login		: User
	Component	: PhytecTest 
	Configuration 	: PhytecConfig
	Model Element	: PhytecDefs
//!	Generated Date	: Mon, 8, May 2017  
	File Path	: PhytecTest/PhytecConfig/PhytecDefs.h
*********************************************************************/

#ifndef PhytecDefs_H
#define PhytecDefs_H

#define SYS "/sys"
#include "CommonDefs.h"


#endif
/*********************************************************************
	File Path	: PhytecTest/PhytecConfig/PhytecDefs.h
*********************************************************************/
